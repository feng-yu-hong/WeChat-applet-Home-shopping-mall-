// components/x-segmnentBar/x-segmnentBar.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
    // segmentItems:Array
    segmentItems: {
      type:Array,
      value:[]
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    currentIndex: 0,//当前索引值
  },

  /**
   * 组件的方法列表
   */
  methods: {
    setIdex(index){
      this.setData({
        currentIndex:index
      })
    },

    handlerTap(e){
      // console.log(e.currentTarget.id);
      let cid = e.currentTarget.id
      this.setData({
        currentIndex: cid
      })

      //触发一个自定义事件，并且把数据传递出去
      this.triggerEvent("selectChange", { currentIndex: cid},{})

    }
  }
})
