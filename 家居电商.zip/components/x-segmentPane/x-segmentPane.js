// components/x-segmentPane/x-segmentPane.js
Component({
  options: {
    multipleSlots: true // 在组件定义时的选项中启用多slot支持
  },
    externalClasses: ['segment-cls'],
 
  /**
   * 组件的属性列表
   */
  properties: {
    segmentItems:{
      type:Array,
      value:[]
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    currentIndex:0
  },
  lifetimes: {
    attached: function () {
      wx.setNavigationBarTitle({ title: '999' })
      // 在组件实例进入页面节点树时执行
    },
    detached: function () {
      // 在组件实例被从页面节点树移除时执行
    },
  },
  /**
   * 组件的方法列表
   */
  methods: {
    handlerChange(e){
      console.log(e.detail.current);
      // 1.获取分选选择器组件对象本身

      let segBar = this.selectComponent("#x-sp-sb"); //代表选中组件的意思

      // 2.调用对应的方法

      segBar.setIdex(e.detail.current)
      if (e.detail.current==0){
        wx.setNavigationBarTitle({ title: '首页' })
      } else if (e.detail.current == 1){
        wx.setNavigationBarTitle({ title: '热销产品' })
      } else if (e.detail.current == 2) {
        wx.setNavigationBarTitle({ title: '新品特惠' })
      } else if (e.detail.current == 3) {
        wx.setNavigationBarTitle({ title: '联系我们' })
      }
   
    },

    handSelectChange(e){
      // console.log(e);
      let idx = parseInt(e.detail.currentIndex)
      this.setData({
        currentIndex:idx
      })
    }
  }
})
