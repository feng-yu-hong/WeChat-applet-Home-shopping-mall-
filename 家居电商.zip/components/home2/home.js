// components/home2/home.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {

  },

  /**
   * 组件的初始数据
   */
  data: {
    background: ['/images/home/01banner1.jpg', '/images/home/01banner2.jpg'],
    indicatorDots: false,
    autoplay: false,
    interval: 6000,
    duration: 500,
    num: 0, //第1个轮播图所对应的当前值

    background1: ['/images/home/03banner1.jpg', '/images/home/03banner2.jpg'],
    indicatorDots1: false,
    autoplay1: false,
    interval1: 3000,
    duration1: 500,
    stop:"",
    num1: 0, //第2个轮播图所对应的当前值
  },

  /**
   * 组件的方法列表
   */
  methods: {
    swiperFn(e) {
      //获得当前是第几张图片 -- 索引值
      console.log(e.detail.current);
      this.setData({
        num: e.detail.current
      })
    },
    swiperFn1(e) {
      //获得当前是第几张图片 -- 索引值
      // console.log(e.detail.current);
      this.setData({
        num1: e.detail.current
      })
    },
    btn(){
      
    },
    toTop(e) {
      console.log(e)
      this.setData({
        stop:0
      })
      //返回顶部
      // console.log(e.detail);
      // wx.pageScrollTo({
      //   scrollTop: (e.detail),
      // })
    }
  }
})
