// pages/contact/contact.js
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },

  methods:{
    
  }
})