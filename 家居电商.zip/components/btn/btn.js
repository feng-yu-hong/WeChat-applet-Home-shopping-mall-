// components/btn/btn.js
Page({

  /**
   * 页面的初始数据
   */
  //返回顶部
  toTopFn(){
    // console.log(123425)
    this.triggerEvent('totop',0)
  },
  //拨打电话
  callFn(){
    wx.makePhoneCall({
      phoneNumber: '15302391170',
    })
  },
  //跳转地图
  jumpToMap(){
    wx.navigateTo({
      url:'/components/map/map'
    })
  },
  data: {

  },

})