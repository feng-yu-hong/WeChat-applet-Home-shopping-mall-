Page({
  // handSelecT(e){
  //   console.log(e)
  // },
  /**
   * 页面的初始数据
   */
  data: {
    items:[
      {
        title: "",
        subtitle:"首页"
      },
      {
        title: "",
        subtitle: "热销产品"
      },
      {
        title: "",
        subtitle: "新品特惠"
      },
      {
        title: "",
        subtitle: "联系我们"
      }
    ]
  }
})